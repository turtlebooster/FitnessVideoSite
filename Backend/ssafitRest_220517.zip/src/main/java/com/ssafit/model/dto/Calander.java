package com.ssafit.model.dto;

import lombok.Data;

@Data
public class Calander {
	private String userId;
	private int todoId;
	private String date;
	private int dayOfWeek; 
	private int eatCalories;
	private int useCalories;
}
/*
user_id varchar(50) PK 
todo_id int AI 
date date PK 
day_of_week int 
eat_calories int 
use_calories int
*/