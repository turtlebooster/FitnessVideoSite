package com.ssafit.model.dto;

import lombok.Data;

@Data
public class Review {
	private int no;
	private String content;
	private String userId;
	private String regTime;
	private String videoId;	
	private int likeCnt;
	private int dislikeCnt;
}
/*
no int AI PK 
content varchar(2000) 
user_id varchar(50) 
reg_time timestamp 
video_id varchar(30) 
like_cnt int 
dislike_cnt int
*/
