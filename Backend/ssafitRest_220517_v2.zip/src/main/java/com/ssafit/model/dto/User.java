package com.ssafit.model.dto;

import lombok.Data;

@Data
public class User {
	String id;
	String password;
	String email;
	String nickname;
}
