package com.ssafit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsafitRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsafitRestApplication.class, args);
	}

}
