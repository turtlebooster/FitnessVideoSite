<template>
  <div class = "">
      <h2>비디오 디테일</h2>

      


  </div>
</template>

<script>
export default {
  name: "VideoDetail",
}
</script>

<style>

</style>