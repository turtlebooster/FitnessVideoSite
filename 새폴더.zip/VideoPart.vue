<template>
  <div>
      <div>
    <h2>
      비디오 파트
    </h2>
    <b-card
    width="320"
    height="180"
    title="제목제목제목제목제목제목제목제목제목제목제목제목"
    img-src="https://img.youtube.com/vi/gMaB-fG4u4g/mqdefault.jpg"
    img-alt="Image"
    img-top
    tag="article"
    style="max-width: 20rem;"
    class="mb-2"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen
     >
    <b-card-text>
     내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용
    </b-card-text>
     </b-card>

    <b-card
                width="320"
                height="180"
                img-src="https://img.youtube.com/vi/swRNeYw1JkY/mqdefault.jpg"
                title="대충 제목 2"
                frameborder="0"
                img-alt="Image"
                img-top
                tag="article"
                style="max-width: 20rem;"
                class="mb-2"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen
                >
    <b-card-text>
     내용내용내용2
    </b-card-text>
    </b-card>
            <b-card
                width="320"
                height="180"
                img-src="https://img.youtube.com/vi/54tTYO-vU2E/mqdefault.jpg"
                title="대충 제목 3"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen
                >
    <b-card-text>
     내용내용내용3
    </b-card-text>
    </b-card>
  </div>
  </div>

  
</template>

<script>
import { BCard } from 'bootstrap-vue'

export default {
name: "VideoPart",
  components:{
    BCard
  }
}
</script>

<style>

</style>