<template>
  <div>
    <h2>검색 결과 창</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>