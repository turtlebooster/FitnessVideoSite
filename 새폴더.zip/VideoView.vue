<template>
  <div>
   <div class="search">
   <input type="text" v-model="keyword" placeholder="제목을 입력하세요">
   </div>
   <div>
      <h2>운동 영상 목록</h2>
      <button @click: = "part(전체)" id = "전체">전체</button>
      <button @click: = "part(전신)" id = "전신">전신</button>
      <button @click: = "part(상체)" id = "상체">상체</button>
      <button @click: = "part(하체)" id = "하체">하체</button>
      <button @click: = "part(복부)" id = "복부">복부</button>
      <div>
        <video-part></video-part>
      </div>
  </div>
  </div>
</template>

<script>
import VideoPart from '@/components/video/VideoPart.vue'
export default {
   components:{
     VideoPart
   },
   data() {
    return {
      keyword:''
    }
  },
  methods: {
    search() {
      this.$store.dispatch("searchVideo", this.keyword)
    },
    part(){
      this.$store.dispatch("partVideo", this.part.id)
    }
  }
}
</script>

<style>
.search {
  position: relative;
  width: 600px;
}

input {
  width: 200%;
  border: 1px solid #bbb;
  border-radius: 8px;
  text-align: center; 
  padding: 10px 12px;
  font-size: 14px;
}

</style>